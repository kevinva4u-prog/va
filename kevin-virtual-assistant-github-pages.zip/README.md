# Kevin — Virtual Assistant Landing Page

This is a GitHub Pages-ready static website.

## Publish with GitHub Pages

1. Create a new GitHub repository, for example `virtual-assistant`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.
7. GitHub will provide your public Pages URL.

The contact buttons use `mailto:kevin.va4u@gmail.com`.
